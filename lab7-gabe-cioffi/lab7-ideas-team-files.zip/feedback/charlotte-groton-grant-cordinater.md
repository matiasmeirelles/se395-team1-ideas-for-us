# Feedback: Grant Cordinater
**Author:** Charlotte Groton
**Saved:** 11/12/2026, 4:32:17 PM

Testing method

This is a hypothetical feedback session based on our proposed AI grant workflow for IDEAS For Us. We did not test a working interface or run data through an application. Taylor’s comments identify expectations and potential problems to check before the partner demo.

Persona: Taylor Bennett, Grant Coordinator

Step 1: Enter project information

I would start by entering the project’s purpose, location, budget, and contact person. I would expect to reuse those details for multiple grant opportunities. My next action would be to check whether the information is complete. If the budget or location is missing, I need the tool to flag that instead of filling it in for me. Reentering the same project details for every application would be frustrating.

Step 2: Review grant opportunities and eligibility

I would look at the deadline, funding amount, geographic restrictions, and required attachments before spending time on a draft. I would then check the original funder guidelines. A general environmental focus does not automatically make a grant a match for our project. I need a clear explanation of why an opportunity fits and which requirements still need verification.

Step 3: Review the draft

I would check the project details and requested amount against our records. I would expect missing information to be clearly marked. My next action would be to send the draft to the appropriate reviewer. I would be concerned if the draft included unsupported impact numbers or commitments our staff had not approved. I need to know what information came from our team and what still requires confirmation.

Step 4: Track approval and submission

I would check the application status, responsible person, and next action. “Done” would confuse me because it could mean several things. I need separate statuses for draft complete, awaiting approval, approved, and submitted. Before marking something submitted, I would want a confirmation number or another record of submission.

Step 5: Track the outcome

After submission, I would record whether the application is pending, awarded, or declined. I would also save feedback and any follow-up date. Tracking outcomes is useful because I do not want our team to lose the information we need when deciding whether to apply again.

Closing questions
1. Would you use this tool next week? Why or why not?
I would try a working version with a few applications next week. I would keep checking it against our existing records until I knew the deadlines and statuses were reliable. The proposed workflow could save me time, but I cannot judge its usability from a description alone.
2. What is the single most important thing to fix before you would trust this?
Before I trusted it, I would need to verify that “submitted” means the application actually reached the funder. Internal approval must not automatically count as submission.
3. What did this tool get right about your workflow?
The proposed workflow recognizes that drafting is only part of grant work. Review, deadlines, missing documents, and outcome tracking matter too. Bringing those tasks together would address the scattered updates I deal with.
4. If you had to explain this tool to a coworker in one sentence, what would you say?
It is a proposed grant assistant that helps us organize opportunities, prepare drafts, and track applications while keeping staff responsible for review and submission.

Synthetic data review

I reviewed the ten fictional records from Step 2. These are expected checks, not observed software results.

Records 01 and 02: I would notice the same project and amount under slightly different funder names. The tool should flag a possible duplicate and ask me to review it before merging anything.

Record 03: I cannot act on “next Friday” without the original date. The deadline should remain unknown until someone verifies it.

Record 04: The draft is approved but not submitted. The tool should preserve that distinction and clearly display the Pacific Time deadline.

Record 05: This record includes a submission confirmation. I would expect that confirmation to remain attached to the application.

Record 06: I would flag the match requirement. Volunteer time does not satisfy the stated cash-match requirement, so the application is not ready as recorded.

Record 07: The Orlando project conflicts with the funder’s Georgia-only restriction. I would question the “Eligible” status immediately.

Record 08: The request is much higher than the stated award maximum. The tool should flag it for review instead of silently changing the amount.

Record 09: The names O’Connell and Zoë should remain intact when records are saved or exported.

Record 10: “Sent to director” does not establish submission to the funder. I would need to identify an owner and verify the actual status.