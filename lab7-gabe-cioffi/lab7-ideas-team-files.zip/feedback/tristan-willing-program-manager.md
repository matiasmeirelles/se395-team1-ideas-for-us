# Feedback: Program Manager
**Author:** Tristan Willing
**Saved:** 11/17/2026, 4:14:40 PM

Step 1: Getting in

What I see: A dark chat window on the left full of “pkill,” “localhost:8501” and “Exit 144.” The app itself is on the right.

What I expected: A link, or something I tap and it opens.

What I’d do: Honestly? If Brianna sent me this and I had to type that gray box of code, I’d text her “can you just show me on Thursday.” I’m assuming someone techy sets it up and I never see that part. If that’s not true, I’m already out.

What’s missing: Can I open this on my phone? It runs “on a computer,” so does that mean only one computer? Most of my grant reading happens in a parking lot.

Step 2: The Grants page

What I see: “Grants,” four zeros (Active, Pipeline $0, Awaiting review, Due in 14 days) and a “New grant” form open below.

What I expected: A place to type “Fleet Farming” and see what fits. Or at least somewhere to paste the link Brianna sent me and get told “fits / doesn’t fit, here’s why.”

What feels wrong: This screen assumes we’ve already decided to apply. My whole problem happens before that. I’m the one figuring out if it’s even worth applying, and there’s nowhere for that here.

What I’d click: The “New grant” form, since it’s the only thing to do.

Step 3: The New grant form

Going field by field:

Grant name*, Funder*: Fine, I can copy those from the email.
Funder type (foundation): Okay. I’d probably leave it.
Amount requested ($) — 0: I don’t know this. That’s Brianna’s call, or our ED’s. I’d leave it at 0, and now the “Pipeline $0” up top is lying.
Deadline 2026/12/05: Fine. But is that already filled in, or is it an example? I’d worry it saves a fake date if I skip it.
Test data (excluded from counts and exports): I have no idea what this is or why I’d check it. It makes me nervous, like I could break something.
Application questions, “one per line, add a limit with ‘| 250 words’”: This is where you lose me. I have to type the funder’s questions myself, with a pipe symbol? I don’t even know where the pipe key is on my phone. The questions are in the RFP. Why can’t I upload the PDF or paste the link and have it pull them out?

What’s missing, and what I really need on this screen:

Somewhere to paste the RFP link or upload the PDF
An eligibility check before “Create grant”: geography (Orlando/Orange County?), cash match, whether it’s reimbursement-based, and whether “environmental” includes urban ag and food access
Who on our team is responsible: me for facts, Brianna for writing

Step 4: The sidebar

What I see: Grants, Write, Review, Tracker, Profile. “Clay (placeholder) — approver.” A yellow box: “No ANTHROPIC_API_KEY in .env — AI writing is off.”

Confused by:

Who’s Clay? And I’m not an approver. I give the numbers and say “yes this fits.” Is there a role for me?
The yellow box reads like an error message. I don’t know what an API key is. If AI writing is off, what does this tool even do right now? I’d assume it’s broken and close it.
“Tracker” vs “Grants”: What’s the difference? Grants already looks like a tracker.

What I’d click next: Profile. I’m hoping that’s where our program info lives: Fleet Farming, harvest numbers, farmlettes. That’s the part I actually care about. If Profile is just my name and email, I’m disappointed.

What works

It’s not cluttered. I’m not drowning in buttons.
“Due in 14 days” up top is exactly what I’d glance at. Good.
Only two fields are required to start. That respects my time, mostly.

Where I am after ~5 minutes

I haven’t done anything useful yet. I’ve filled in a form for a grant I still don’t know we qualify for. If the next screen doesn’t show me either (a) where our program numbers live, or (b) a fit check with match and eligibility up front, I’ll be at minute 10 and go back to reading the PDF on my phone.

Can you show me Profile next? And the Write and Review screens. I want to see what it does with our numbers. Does it make anything up, and does it tell me when it’s missing something?

1. Would I use it next week?
Probably not. I’d use it if Brianna sat next to me and set it up. What I’ve seen so far starts after the decision to apply, but I spend most of my time before that decision, reading RFPs to find out if we even qualify. Right now it would add a step to my week. I’d still have to read the PDF, and on top of that I’d type the funder’s questions in with pipe symbols. I’d also be nervous about that yellow “AI writing is off” box. If it’s off, why am I here? And if it’s on, what is it writing about my program, and where is it getting the numbers from? I haven’t seen that yet.

2. The single most important thing to fix before I’d trust it
Let me paste the RFP link or drop in the PDF, and show me a fit check before I click “Create grant.” It needs geography (Orlando/Orange County), cash match or reimbursement, and whether “environmental” includes urban ag and food access, with the page number where it found each one so I can check. If it can’t find something, it should say “not found, check page X,” not guess. That’s the 40 minutes I lose every week. Fix that and I’ll come back.

(Right behind it is showing me where our program numbers come from, and marking blanks as “[need number from Marisol].” But I can’t judge that until I see Profile and Write.)

3. What it got right

Deadlines up front. “Due in 14 days” on the first screen is exactly the panic number I care about.
Only two required fields. It didn’t make me fill out 30 boxes to get started.
Word and character limits per question. Whoever built it knows funders cap answers at 250 words, and that’s a real headache when Brianna’s drafts run long.
Separate Review and approver steps. It understands that someone checks a draft before it goes out. I just need my part in that to be clear.
The “Test data” checkbox, once someone explained it to me. Keeping fake grants out of the counts is smart, so we don’t report a pipeline that isn’t real. The label just needs to say that in normal words.

4. One sentence to a coworker
“It’s a tracker where Brianna can keep our grants and the funder’s questions in one place, but it doesn’t tell you yet whether a grant actually fits us, so keep reading the RFPs for now.”


Trying to put my “Program Stats MASTER” sheet into the tool.

First problem: I can’t find where it goes.
All I’ve seen is the Grants screen. There’s no “Upload,” no “Import sheet” and no “Connect Google Sheets.” The only box that takes a lot of text is “Application questions,” and that’s for the funder’s questions, not my numbers. Maybe Profile has a spot, but nobody’s shown me Profile yet. And the yellow box says AI writing is off, so even if I got my numbers in, nothing would draft from them.

So I can’t honestly tell you what the tool does with my data. I haven’t seen it happen. What I can tell you is what I’d check the second it let me load the sheet, and what would make me close the laptop.

What I’d check first, in order

Pounds harvested, 2024. This is the one that ends it.
I’d have it draft the answer to “What outcomes has your project achieved?” for a local grant (Orange County).
Bad: it says 38,400 lbs. That’s the org-wide number with the hubs in it, and Brianna’s note even says “use this one for the big asks.” If it grabbed the biggest number, I’m done.
Also bad: it adds 4,812 + 2,100 from Gainesville. Gainesville isn’t us.
What I want: “4,812 lbs (harvest log, 1/14/25). There’s also a 38,400 figure from the annual report draft that looks like it includes hubs. Which one fits this grant?”
Households served: the blank one.
Bad: it writes “~350 households” like it’s a fact. Or worse, “approximately 400 families.”
What I want: “[need number from Marisol — ask Jess for the distro sheet].” Leaving it blank is the correct answer here.
Bonus if it notices: the ~350 note says “includes farmlette hosts.” Those people give us their yards. They’re not the people we’re feeding.
Volunteer hours: 1240 vs 1240.5.
Bad: it averages them, picks one without telling me, or adds them together into 2,480.
What I want: “Two entries for Q2 from different sources. Is this fiscal Q2 (Oct–Dec) or calendar Q2 (Apr–Jun)?” Honestly, I’m not sure myself. Jess’s “dup??” note is right.
The match question.
If the grant needs a 1:1 cash match, does it see “$41,056 in-kind… counts toward match!!” and say we’re fine? That would be a false “fits,” because volunteer time isn’t cash. I’d want a red flag: “Requires a cash match. In-kind volunteer value probably doesn’t count.”
“1.2k youth participants.”
If this shows up as “over 1,200 youth engaged,” I’d be mortified. That’s the whole school, not our kids. It should at least ask “1.2k? From a partner report, please confirm.”
Program names.
Does it know “FF,” “Fleet Farm” and “fleet farming” are all us? If it lists them as four programs, it’s useless. But if it merges “IDEAS Hub – Gainesville” into Fleet Farming because they both have “pounds harvested,” that’s the hub problem again.
“Parramore – Café con Huertos 🌱.”
Small thing, but if it shows up as “CafÃ© con Huertos” or the name gets cut off at the dash, I’ll notice right away. That’s our Spanish-language workshop with the church, and I don’t want the partner seeing their name mangled. And it’s Huertos.
Budget “$186,500 “.
If it shows “Pipeline $0” when we have a budget sitting right there, I’m confused. But I’d also want it to ask whether that’s program-only or includes overhead, like the note says. That’s for Dana, not me.
The broken “4,812 / 27”.
If it puts that text straight into a draft, that’s sloppy. If it turns it into “178 lbs per farmlette,” that’s a number we never agreed on. And which farmlette count? 27, ~30 or 31?