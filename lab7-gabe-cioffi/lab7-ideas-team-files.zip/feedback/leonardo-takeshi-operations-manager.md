# Feedback: Operations Manager
**Author:** Leonardo Takeshi
**Saved:** 11/12/2026, 4:27:08 PM

Persona: Dana Whitfield (Operations Manager). MVP shown: the IDEAS Grant Runway full-schema PDF export from Grant Nexus (generated Nov 12, 2026; 216 records, 157 pages). Option A: reviewed the tool's real output.

STEP-BY-STEP WALKTHROUGH

1. Cover page (summary)
- Sees: 216 records, 72 with deadlines, 144 rolling; 86 verified vs 130 unverified; urgency counts (Critical 12, High 4...).
- Reaction: "The summary is good. But 130 of 216 are unverified? So most of this list might not be real. I'd want that number in red."
- Missing: a "start here" list, like "the 5 grants worth your time this week."

2. "Corrections applied on the Runway" section
- Sees: notes like "queued via research memory run 51," "STEP 4," "data.js," "build defect," plus broken text like "&amp;" and "&quot;" and cut-off sentences ("as &quot;2 (queued...", "Record in `disco").
- Reaction: "This reads like notes from the developer, not for me. What is a 'research memory run'? And 'queued, not yet applied' — is the record still wrong in this export or not?"
- Feels wrong: The garbled symbols and half-sentences make me trust the whole document less.
- Missing: plain-language status: "Fixed" / "Still wrong — don't use" / "Needs your decision."

3. Critical list (due in the next 7 days)
- Sees: 12 Critical grants. Good ones like Southern SARE On-Farm Research (Fit 78, verified, quotes the funder) and Impact Polk 2027 (Fit 78).
- Feels wrong: 3 of the 12 are "No pillar match" and unverified: Lumina Postsecondary Attainment, STEM Literacy K-12, Precision Preventive Care. "Why is a health care grant in my critical list? We're an environmental group."
- In High: "Translational Genomics for Rare Disease" is tagged pillar "Ecology." "That's just wrong, and it makes me doubt the other pillar tags."
- Missing: hide or move to the bottom anything under Fit 50 or unverified; "Critical" should mean urgent AND worth it.

4. A single record (e.g., Southern SARE)
- Works well: description, eligibility in plain words, why IDEAS qualifies (Fleet Farming, Hardee County biochar), verification with date and source. "This is exactly what I need to approve something."
- Feels wrong: A long "NOT RECORDED" list on every record (Contact Email, Mission, Match Score, Data Reef Alignment...). "Half the fields are empty. What is 'Data Reef Alignment'?"
- Missing: contact person for most records.

5. My first check: match / cost-share and reimbursement
- Sees: It's sometimes there, but buried inside the description or the Runway Note (e.g., "Cost-share: labour or cash match required" on Love Your Lake). Only about 20 mentions across 216 records.
- Reaction: "Partly gets it. But I have to read every paragraph to find it. That should be its own field with a red/yellow/green flag."

6. Format overall
- Reaction: "157 pages. I'm not reading this. I'd print page 1 and the Critical section. Footer reminder to confirm on the funder's page is good."

CLOSING QUESTIONS
1. Use it next week? "Yes, but only the verified Critical and High records, and only after someone deletes the ones that obviously aren't us. I wouldn't hand the full export to Clay."
2. Most important fix: "Get unverified and no-pillar-match grants out of the urgent list. If the top of the list has a rare-disease genomics grant, I stop trusting the rest."
3. What it got right: "The verified records are excellent: plain eligibility, why we qualify, and proof it was checked on the funder's site. And it catches its own mistakes, like closed programs that still looked open."
4. One sentence to a coworker: "It's a list of every grant we might go after, sorted by deadline; the verified ones are solid, but double-check anything marked unverified."

DATA STRESS TEST (my synthetic data vs. what the export shows)
- Duplicates: The tool already caught one (American Honda stale duplicate), so it can detect them. My #1/#2 and #6/#15 rows would need the same check before they inflate counts.
- Inconsistent fields: The real export already shows this. "Rolling Deadline" has four different values: Yes (144), No (47), false (10), "true, semi-annual reviews" (1). A filter on "Yes/No" would silently miss 11 records.
- "Rolling" that's actually closed: Corrections show several (Cornelia T. Bailey, Herman's Garden, Wawa paused until Jan 2027). With 144 rolling records, more are probably stale. My "rolling/TBD/quarterly" rows would show as open forever.
- Special characters: Already broken in the real export ("&amp;", "&quot;"). My "Ben & Jerry's" and "Fundação" rows would display wrong.
- Huge/unverified amounts: Real example — Lumina "$50,000 - $1,000,000," unverified, fit 40, sitting in Critical. My $1M anonymous fund would rank the same way.
- Match / reimbursement: No dedicated field. My EPA reimbursement row and City of Orlando volunteer-hour match would only be caught if someone reads the description.
- Funder bans AI: No field for it anywhere. My Patagonia row would go straight through.
- Renewal vs new lead: The tool flagged Edyth Bush as a "focus mismatch" but has no field for "we've been funded before."

MOST SURPRISING COMMENT: "If the top of the list has a rare-disease genomics grant tagged 'Ecology,' I stop trusting the rest." The good records are very good, but a few obviously wrong ones in the urgent section can sink trust in the whole tool.