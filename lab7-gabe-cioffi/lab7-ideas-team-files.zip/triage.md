# Triage
**Author:** Charlotte Groton
**Saved:** 11/17/2026, 3:52:02 PM

# IDEAS Grant Runway: Grant Writer Persona Test Feedback

**Tester persona:** Sarah Mitchell (fictional), Grant Writer, IDEAS For Us. Five years in nonprofit fundraising, moderate tech comfort, about 10 minutes to try a new tool.
**Tool tested:** Editable copy of IDEAS Grant Runway (https://claude.ai/artifact/7KfahagB98FfFw8nzQSsCo)
**Test date:** November 12, 2026
**Method:** Live clicks in Chrome on the published copy. Nothing was submitted, sent or approved. Filters and search were reset afterward.

## Test setup and limitations

- The Runway was actually opened and used. The search, filters, requirements view and packet window were all clicked through live.
- **The tool has no way to import a spreadsheet.** The 15 messy test records could not be loaded, so the import and edge-case steps could not be run. The record audit below is a manual reading of the test rules, not tool output.
- Funder links and grant facts in the Runway were not re-checked against live websites during this test.
- The 15 test records are fictional. None of them can be called genuinely open.

## Sarah's walkthrough

### 1. First impression

- **What she sees:** A "This week" view with three grant cards (deadline, owner, next step, and Sent / Not sending / Missed buttons), pipeline money totals, urgency counts, and a 120-day timeline.
- **What works:** She understands it within a minute. It reads like her Monday deadline spreadsheet.
- **What confuses her:** Terms like "Ready 43", "Priority 31", "Gate" and "Grant Nexus", and file names like `applications/_owners.json` and `_open-questions.md`. These mean nothing to her.
- **Impact:** Lost trust and time on the first screen.
- **Fix:** Add a one-line explanation beside Ready and Priority, and replace file names with plain words such as "add an owner".

### 2. First search: environmental grants, Florida or nationwide, $10K–$100K, open now

| What she typed or clicked | Result |
|---|---|
| "environmental sustainability" | **0 dated · 0 rolling.** No message, and the page jumped to the Missed list |
| "sustainability" | **0 results** |
| "Florida" | 15 dated · 21 rolling |
| "Florida" + Apply directly | 11 dated · 15 rolling |
| "California" | 0 results (correct) |

- **Problem:** Search only matches funder and grant names and locations, not topics. For an environmental grant tool, getting nothing back for "sustainability" looks broken.
- **Problem:** There is no award filter. $250–$5K, $1M and $2.5M–$100M grants all appear alongside her $10K–$100K preference.
- **Problem:** Grants a Florida nonprofit can't apply to still appear. The Keidanren Nature Conservation Fund (developing countries / Japan) is listed with an "Apply: Online application" tag.
- **Impact:** Sarah wastes time or decides the tool doesn't work. Unqualified results bury good ones.
- **Fixes:**
  - Search the summary, eligibility text and focus areas too, not just names.
  - Show "No matches — try the Water or Ecology filter" next to the search box when nothing is found.
  - Add an award-range filter that ranks by preference instead of hiding results.
  - Hide grants with a known geographic exclusion by default, with a "Show ineligible" toggle.

### 3. Eligibility details (the Requirements view)

- **What works:** This is the best part of the tool. Each requirement is marked Met, Condition, Unknown, Not met or Note, with the evidence written underneath, including where facts are still open questions. This is exactly what Sarah wants.
- **Problem:** The ranking contradicts the details. Duke Energy Foundation Florida Grants has two **Not met** items (no electricity-generating equipment, no weatherization or energy-efficiency work), yet it is still ranked **96 Strong**, tagged with the Energy pillar, and labelled "Apply: Online application". Its own notes say the process starts by contacting Duke's state representative.
- **Problem:** "Not met" here means "this funder bans part of IDEAS's work", but Sarah reads it as "IDEAS is ineligible".
- **Impact:** Wrong prioritization. This is the exact mistake Sarah calls a dealbreaker.
- **Fixes:**
  - Rename "Not met" on restrictions to "Excluded activity".
  - Lower the fit score, or show a warning on the card, whenever any item is Not met.
  - Tag grants that need a contact first as "Contact funder first", not "Online application".

### 4. Deadlines and expired grants

- **What works:** Passed deadlines move into a separate "Missed & decided" section. The notes at the bottom say 12 grants whose deadlines had passed were dropped. Each grant shows days left and the exact date.
- **Problem:** The Impact Polk packet is still listed under "Drafted, still live" after its Nov 9 internal deadline (gate) passed. Its text still says "12 days from this draft" when only 4 days are left.
- **Fix:** Work out day counts in packet text when the page loads, and move a packet out of "still live" once its internal deadline has passed and nothing is recorded.

### 5. Review and submission controls

- **What works:**
  - Packets say "Nothing has been submitted. A person reviews and submits."
  - Unknown figures are left blank as `[NEEDS FIGURE]` instead of made up.
  - Official funder and guideline links are cited.
  - Nothing in the tool sends or submits anything.
- **Problem:** The **"Sent"** button sounds like it sends the application. It only records that a person already submitted it.
- **Problem:** **"Approve for applications/"** doesn't say what happens when you click it.
- **Impact:** Risk of a false belief that something went out, or fear of clicking at all.
- **Fixes:** Rename "Sent" to "Mark as submitted" and "Approve for applications/" to "Approve draft (does not submit)".

### 6. Messy-data import

- **Result:** Not testable. The Runway has no way to import or paste spreadsheet rows, only its own research data.
- **Impact:** Sarah can't check her existing Google Sheets tracker against the tool.
- **Fix:** Add a CSV / Google Sheets import that keeps every row, stores the original values beside the cleaned ones, flags duplicates, and never drops rows without saying so.

## Messy synthetic data test (live attempt)

Sarah tried to run her 15-row tracker through the tool.

| What she tried | What happened |
|---|---|
| Look for an import, upload or paste option | **None exists.** The only data in the tool is the Runway's own research records |
| Search "Green Futures" (records 01/04) | 0 dated · 0 rolling, with no message |
| Search "O'Connor" (record 11, apostrophe) | 0 results. The page did **not** break on the apostrophe, but there's no record to find |
| Search "$10k-50k" (record 02 raw amount) | 0 results, because amounts aren't searchable |
| Each search | The page jumped down to the Missed list, away from the search box |

**What breaks:** the whole import step. None of the edge cases (duplicate 01/04, expired 06, California-only 08, blank deadline 09, $2.5M / $5M budget 10, fiscal sponsor 13, invitation-only 05) can reach the tool, so none of its handling can be checked.

**What gets silently wrong:** an empty result shows "0 dated · 0 rolling" with no explanation. Sarah can't tell "no such grant", "not imported" and "search doesn't look there" apart. She might wrongly conclude a grant from her tracker is ineligible or closed.

**What Sarah notices immediately:** "Where do I put my spreadsheet?" Without import, the tool can't replace her Google Sheets tracker. She'd have to keep both.

**How the tool's own data handles the same kinds of edge cases (from browsing it):**

| Edge case | Runway behavior | Verdict |
|---|---|---|
| Expired deadline (like 06) | Moved to "Missed & decided"; 12 stale records disclosed at the bottom | Good |
| Geographic exclusion (like 08) | Keidanren (Japan / developing countries) still listed as "Apply: Online application" | Fails |
| Month-only or unclear deadline (like 10) | Not observed in this test | Untested |
| Invitation-only or contact-first (like 05) | "Letter of inquiry first" and "Contact funder first" tags exist, but Duke is mis-tagged "Online application" | Mixed |
| Budget threshold (like 10) | Shown as "Condition" / "Unknown" with evidence (e.g. DARRP notes say the $2.5M minimum is about twice IDEAS's revenue) | Good |
| Duplicates (like 01/04) | Not observed in this test | Untested |
| Unknown facts | Left as `[NEEDS FIGURE]` / "Unknown", never made up | Good |

**Fix:** add a CSV / Google Sheets import that:
- keeps every row and its raw values;
- turns "25k", "$40k" and "$10k-50k" into numbers while keeping the original text;
- reads "12/15/26", "12-15-2026" and "Dec 1 2026" as dates, and marks "Mar 2027" as month-only;
- flags likely duplicates for a person to confirm;
- marks blanks as "unknown";
- runs every row through the same Requirements check.

Also show why a search returned nothing.

## 15-record audit (manual, not tool output)

| ID | Funder | Award | Deadline | Duplicate? | Status | Issue / next action |
|---|---|---|---|---|---|---|
| 01 | Green Futures Foundation | $25,000 | Dec 15, 2026 | Yes, with 04 | possible match | Keep one record; confirm the program page |
| 02 | EcoAction Community Grant | $10,000–$50,000 | Dec 1, 2026 | No | needs verification | Confirm the 501(c)(3) requirement and documents |
| 03 | Sunshine Enviro Fund | $75,000 | Nov 30, 2026 | No | possible match | Florida only; confirm IDEAS has a watershed project |
| 04 | Green Futures Fdn. | $25,000 (raw "25k") | Dec 15, 2026 | Yes, with 01 | duplicate | Merge with 01 |
| 05 | National Climate Initiative | $100,000 | TBD | No | needs verification | Possibly invitation only; don't show as open |
| 06 | Urban Tree Project Grants | $15,000 | Oct 1, 2026 | No | expired | A live "APPLY" button doesn't prove it's open |
| 07 | BlueWater Conservation Fund | $40,000 (raw "$40k") | Jan 15, 2027 | No | needs verification | 20% match: confirm whether it's based on the request or the total project cost; don't commit funds |
| 08 | CA Green Cities Grant | $60,000 | Feb 1, 2027 | No | excluded by known restriction | California applicants only |
| 09 | Community Roots Initiative | $8,500 | Unknown (blank) | No | needs verification | No deadline; below the preferred range but not ineligible |
| 10 | Global Eco Impact Fund | $2,500,000 | March 2027 (month only) | No | needs verification | Requires a $5M+ annual budget; IDEAS's budget not confirmed |
| 11 | O'Connor Environmental Trust | $20,000 | Jan 20, 2027 | No | needs verification | Apostrophe kept; confirm the past grant report was filed |
| 12 | RiverKeepers Fund | $30,000 | Dec 10, 2026 | No | needs verification | Reimbursement only; IDEAS must spend the money first |
| 13 | Clean Earth Foundation | $35,000 | Nov 18, 2026 | No | needs verification | Fiscal-sponsor rule unclear; due in 6 days |
| 14 | Neighborhood Green Grants | $12,000 | Rolling | No | needs verification | Link missing; needs a project location |
| 15 | Eco Innovations Program | $50,000 | Dec 31, 2026 | No | needs verification | Research institutions only; a university may have to lead |

## Critical failures: fix now

| # | Problem | Found in | Fix |
|---|---|---|---|
| 1 | Topic search returns nothing ("sustainability" = 0) | First search | Search summaries, eligibility and focus areas; show a no-results hint |
| 2 | Top-ranked grants carry "Not met" items | Requirements view (Duke Energy) | "Not met" lowers the score and shows a warning on the card |
| 3 | No spreadsheet import | Messy-data import | Add a CSV / Sheets import that keeps raw values and flags duplicates |
| 4 | "Sent" and "Approve for applications/" are misleading | Review controls | Rename to "Mark as submitted" and "Approve draft (does not submit)" |
| 5 | Geographically ineligible grants shown as appliable | First search (Keidanren) | Hide known exclusions by default |

## Improvements: fix later

- An award-range filter, treated as a preference.
- Plain-language explanations for Ready, Priority and Gate.
- Packet day counts worked out live, not frozen at the date the packet was drafted.
- Separate tags for "Match required", "Reimbursement only", "Invitation only" and "Contact funder first".
- Filters that also apply to the "This week" cards (today they only change the counts and lists below).
- Remove file names (`applications/…`, `_open-questions.md`) from staff-facing text.

## Out of scope / ignore

- **Light/dark switch and chart styling:** these don't affect grant decisions.
- **Export format details (CSV/PDF columns):** useful later, but not part of Sarah's first 10 minutes.

## Closing answers in Sarah's voice

1. **Would you use this tool next week?**
   "Yes, but carefully. The requirements breakdown would save me hours. It shows which rules we meet, which we don't, and why. I'd use it to cut my list down, then check anything marked 'Strong' myself, because one top-ranked grant had two 'Not met' items. And I'd stop searching by topic, since 'environmental sustainability' gave me nothing."

2. **Single most important fix before you'd trust it?**
   "The ranking has to agree with the details. If a grant says 'Not met' anywhere, it can't also say '96 Strong' and 'Apply: Online application.' That's exactly the mistake I'm trying to avoid."

3. **What did it get right about your workflow?**
   "It never pretends. It leaves blanks instead of making up figures, links to the funder's own page, and says plainly that nothing was submitted. Expired deadlines are kept separate, and the 'This week' view shows what's due, who owns it and what's blocking it, which is what my Monday spreadsheet is supposed to do."

4. **One sentence for a coworker:**
   "It's a grant deadline board that does the eligibility homework for you. Just don't trust the 'Strong' label without opening the requirements, and search by state, not by topic."

## Questions for IDEAS For Us staff

1. What was IDEAS's actual annual operating budget last fiscal year? It decides record 10 and every funder's percentage cap.
2. Does IDEAS have cash or in-kind support it could commit to a 20% match (record 07)? Who is allowed to approve a match?
3. Are any past grant reports outstanding that would block new applications (record 11)?