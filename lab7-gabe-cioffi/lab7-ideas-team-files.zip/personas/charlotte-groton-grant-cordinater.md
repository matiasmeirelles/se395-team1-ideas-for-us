# Persona: Grant Cordinater
**Author:** Charlotte Groton
**Saved:** 11/12/2026, 4:24:03 PM

## Persona

Taylor Bennett is a 28-year-old grant coordinator at IDEAS For Us. Taylor tracks deadlines, required documents, approvals, and application outcomes while juggling other administrative responsibilities.

Taylor uses Gmail, Google Docs, and spreadsheets daily. They can update an existing Airtable table but have never built an automation or used an API. They have about ten minutes to try a new tool.

Taylor’s biggest frustration is that application updates are scattered across emails and documents. When someone says an application is “done,” Taylor cannot tell whether the draft is finished, leadership approved it, or it was actually submitted.

Taylor would stop using a tool if it marked applications as submitted without confirmation or guessed missing deadlines instead of flagging them.

The first thing Taylor would check is whether the tool clearly separates “draft complete,” “approved,” and “submitted.” Each application should show who owns it and what needs to happen next.

Taylor wants to open one dashboard and quickly see upcoming deadlines, missing documents, applications awaiting approval, and confirmed submissions.

## Synthetic Data

All records below are fictional testing data. Blank fields represent missing information.

| ID | Funder | Project | Request | Deadline | Status | Owner | Notes |
|---|---|---|---|---|---|---|---|
| 01 | Green Horizon Fund | Orlando garden | $15,000 | 12/01/2026, 5 PM ET | Draft complete | Taylor | Budget attachment missing. |
| 02 | green horizon fund | Orlando comm. garden | 15000 | Dec 1, 2026 | In progress | T. Bennett | Duplicate of record 01 from a separate email. |
| 03 | Sunroot Foundation | Solar workshop | $8,500 | | Researching | Jamie | Note says “next Friday,” but the original email date is missing. |
| 04 | Waterway Partners | Creek cleanup | $12,000 | 12/04/2026, noon PT | Approved | Morgan | Director approved the draft. Application has not been submitted. |
| 05 | Oak & River Trust | Youth garden | $20,000 | 12/08/2026 | Submitted | Taylor | Portal confirmation WR204 received November 10. |
| 06 | Neighborhood Futures | Garden equipment | $7,500 | 12/10/2026 | Ready to submit | Jamie | Requires a 1:1 cash match. Budget lists $7,500 in volunteer time as the match. |
| 07 | Urban Canopy Circle | Orlando tree planting | $25,000 | 12/12/2026 | Eligible | Morgan | Funder only supports projects located in Georgia. |
| 08 | Community Roots | Food access program | $1,500,000 | 12/15/2026 | Drafting | Taylor | Maximum award is $15,000. Requested amount may be a typo. |
| 09 | O’Connell Community Fund | Compost education | $6,000 | 12/16/2026 | In review | Zoë | Special characters in the funder and owner names must be preserved. |
| 10 | Tomorrow’s Habitat | Habitat restoration | $18,000 | 12/18/2026 | Submitted? | | Note says “sent to director.” No funder submission confirmation exists. |

The domain-specific gotcha is record 06. Volunteer time does not satisfy this funder’s cash-match requirement, so the application should be flagged for review.

The tool should also flag duplicate records, missing deadlines and owners, geographic eligibility conflicts, and requests above funding limits. It should account for deadline time zones and distinguish internal approval from actual submission.

These are sample test cases, not observed results. They have not yet been run through the MVP.