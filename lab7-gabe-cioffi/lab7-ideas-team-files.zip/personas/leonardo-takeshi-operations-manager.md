# Persona: Operations Manager
**Author:** Leonardo Takeshi
**Saved:** 11/12/2026, 4:19:46 PM

## Persona

Name: Dana Whitfield
Age: 41
Role & org: Operations Manager, IDEAS For Us (Orlando environmental nonprofit, about 6 core staff; runs Fleet Farming). Makes sure new tools fit how the team already works, and signs off on every grant before it goes to the CEO.

Tech comfort: Medium-low.
- Uses daily: Gmail, Google Docs/Sheets, QuickBooks, Runway (for deadlines), WhatsApp with volunteers.
- Has tried ChatGPT a few times for emails; has never built a prompt, used an "agent," or connected tools to each other.
- Reviews drafts on her laptop between meetings, often on her phone at night.

Top frustration: Drafts land in her inbox the night before the deadline with no summary of what the funder requires. She has to reopen the RFP herself to check eligibility, match requirements, and budget caps, so "approval" really means redoing half the research. Last cycle she caught a draft citing the wrong number of Fleet Farming farmlets and an outdated budget.

Dealbreaker: If the tool produces a confident draft with a wrong fact about IDEAS (program numbers, budget, partner names) or misses a disqualifying condition, and she only finds out after it's submitted. One embarrassing submission and she goes back to doing it by hand. Also: if she has to enter anything twice (in the tool AND in Runway).

First check: She opens the eligibility/conditions check and looks for match / cost-share and reimbursement terms. A 6-person nonprofit can't front cash for a reimbursement-based federal grant, so if the tool doesn't flag that, it doesn't understand their reality.

Correction I made to the AI: Its first version made her an AI power user like the CEO, who has trained Claude on his voice for years. The real operations role cares about accuracy, risk, and not adding steps, not prompt tricks. I also added that she reviews on her phone.

## Synthetic Data

Synthetic Runway export (funders, amounts, dates invented for testing)

# | Funder | Program | Amount | Deadline | Stage | Program area | Notes
1 | Central FL Community Fdn | Green Neighborhoods | $25,000 | 12/1/26 | Drafting | Fleet Farming | match 1:1 req? check
2 | Central Florida Community Foundation | Green Neighborhoods Grant | 25000 | Dec 1 | Lead | FF |
3 | US EPA | Environmental Education Grants | $4,700,000 | 2027-01-15 | Lead | Education | federal
4 | Orange Cty Env. Protection Div | Urban Ag Pilot | | TBD | Lead | Fleet Farming |
5 | Ben & Jerry's Foundation | Grassroots Organizing | $20,000 | rolling | LOI | IDEAS Hubs |
6 | Duke Energy Fdn. | Environment & Sustainability | $10k | 11/30 | Approved | Solar / Energy |
7 | FL Dept. of Agriculture (FDACS) | Specialty Crop Block | $150,000 | 3/31/2027 | Lead | Fleet Farming | must partner w/ FL ag entity
8 | Winter Park Rotary | Community Grant | $2,500 | 1/10/27 | Submitted | Education |
9 | Fundação Esperança Verde | Intl Youth Climate | €15.000 | 15/02/2027 | Lead | IDEAS Hubs |
10 | Walmart Local Giving | Community Grant | $250–$5,000 | quarterly | Lead | |
11 | Patagonia Env. Grants | Grassroots | $12,000 | 4/1/27 | Drafting | Fleet Farming | funder: "no AI-generated applications"
12 | Edyth Bush Charitable Fdn | Capacity Building | $50,000 | 2/15/27 | Lead | Operations | renewal? funded 2025
13 | City of Orlando | Neighborhood Matching Grant | $5,000 | 1/31/27 | Lead | Fleet Farming | requires 1:1 match
14 | Anonymous Family Fund | | $1,000,000 | 12/15/26 | Lead | ??? | no RFP link
15 | Duke Energy Foundation | Environment & Sustainability | 10000 | 11/30/2026 | Lost | Solar |

Edge cases: duplicates with different spellings (#1/#2, #6/#15 with conflicting stages), blank required fields (#4 amount, #10 program area), huge/unverified numbers (#3, #14), special characters (#5 "&", #9 "ç" and €), mixed date formats (day-first, "rolling," "TBD," "quarterly").

Domain gotchas:
- #3 EPA is reimbursement-based: IDEAS must spend first and get paid back later. A win could cause a cash-flow crisis.
- #11 funder bans AI-generated applications: running the agent on it could break their rules.
- #12 is a renewal, not a new lead: needs last year's report, not a fresh pitch.
- #13 match is volunteer hours, not cash: a "match required = not eligible" rule would wrongly reject it.