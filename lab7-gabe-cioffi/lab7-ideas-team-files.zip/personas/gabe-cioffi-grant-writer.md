# Persona: grant writer
**Author:** Gabe Cioffi
**Saved:** 11/12/2026, 4:06:08 PM

## Persona

Sarah Mitchell
Age: 32

Role: Grant Writer

Organization: IDEAS For Us

Experience: 5 years in nonprofit fundraising, including 2 years focused on environmental grants.

Tech Comfort: Moderate


Background
Sarah works as a grant writer for IDEAS For Us, an environmental nonprofit focused on sustainability and community-based environmental projects. She helps identify funding opportunities, research grant requirements, draft proposals, and coordinate with program staff to collect information.

She balances grant writing with donor communications, reporting deadlines, and other administrative responsibilities. She has limited time to learn new software.
1. Technology Comfort Level
Tools she uses daily:
- Google Docs for writing and editing proposals.
- Google Sheets for tracking grant opportunities and deadlines.
- Gmail for communicating with funders and coworkers.
- Google Drive for storing previous grant applications.
- ChatGPT or Claude occasionally to brainstorm or improve draft wording.
Tools she has never used:
- Coding or Python.
- API integrations.
- Automated web scraping tools.
- Advanced AI agent workflows.
Sarah is comfortable with everyday software but prefers tools that work without complicated setup or technical knowledge.
2. Top Frustration With Current Workflow
Sarah spends several hours each week searching grant databases, foundation websites, and nonprofit newsletters for funding opportunities.

Her biggest frustration is spending time researching grants only to discover that IDEAS For Us does not qualify.

For example, she might spend 30 minutes reviewing a $50,000 environmental grant before discovering it is restricted to organizations in California.

She also has to manually compare opportunities against organizational priorities, geographic eligibility, funding restrictions, and deadlines.

She wishes she could enter IDEAS For Us's eligibility requirements once and receive a list of relevant, verified opportunities.
3. What Would Make Her Stop Using the Tool?
Sarah would stop using the AI grant finder if it repeatedly recommended grants that IDEAS For Us was not eligible for.

Her biggest dealbreaker is inaccurate grant information.

If the tool lists expired opportunities, invents funding amounts, or incorrectly identifies eligibility requirements, she would lose confidence in its recommendations.

She does not have time to independently research every result just to determine whether the AI is correct.

She also would not trust a system that submits applications or makes organizational commitments without staff approval.
4. First Thing She Would Check
Sarah would immediately search for grants using the following criteria:
Sarah's first test search
Focus	Environmental sustainability
Location	Florida or nationwide
Funding amount	$10,000–$100,000
Applicant type	Eligible nonprofit
Deadline	Open opportunities only


She would check whether the results include legitimate grants, working links to official funder websites, current deadlines, and clear explanations of why IDEAS For Us qualifies.

If the tool finds three relevant grants in a few minutes without her having to sort through dozens of irrelevant results, she would consider it useful.
5. A Realistic Quote From Sarah
"I don't need AI to find me 100 grants. I need it to find five that we actually qualify for. If I have to double-check every eligibility requirement and deadline myself, then it's not really saving me time."

Summary
Sarah represents a grant writer who needs an efficient and reliable way to find environmental funding opportunities. She is open to using AI but prioritizes accuracy, simplicity, and transparency. Her willingness to adopt the tool depends on whether it can reduce research time without introducing additional work or risking inaccurate applications.

## Synthetic Data

User Persona: Sarah Mitchell, Grant Writer
Organization: IDEAS For Us
Tool Being Tested: AI-Powered Automatic Grant Finder
Dataset: 15 grant opportunities

This fictional dataset represents a messy Google Sheets document that Sarah might maintain while researching environmental grants for IDEAS For Us.

The data intentionally contains outdated deadlines, duplicate grants, missing information, inconsistent formatting, and eligibility restrictions that could confuse an AI grant-finding system.

Important: All grant names, funding amounts, and deadlines below are invented for testing. They are not verified funding opportunities.
Sample Grant Data
ID	Funder / Grant	Amount	Deadline	Notes from Sarah
01	Green Futures Foundation	$25,000	12/15/26	FL nonprofits, sustainability programs. Looks good.
02	EcoAction Community Grant	$10k-50k	Dec 1 2026	Need 501c3. Check eligibility.
03	Sunshine Enviro Fund	$75,000	11/30/26	FL only. Watershed restoration projects.
04	Green Futures Fdn.	25k	12-15-2026	Same as #1?? Mike added this.
05	National Climate Initiative	$100,000	TBD	US organizations. Invitation only?
06	Urban Tree Project Grants	$15,000	10/01/26	Expired? Website still says APPLY.
07	BlueWater Conservation Fund	$40k	1/15/27	Coastal cleanup, 20% match required.
08	CA Green Cities Grant	$60,000	02/01/27	California applicants ONLY.
09	Community Roots Initiative	$8,500	—	Community gardens, no deadline listed.
10	Global Eco Impact Fund	$2,500,000	Mar 2027	Intl projects. Minimum $5M annual org budget.
11	O'Connor Environmental Trust	$20,000	01/20/27	Florida, restoration. Need past grant report.
12	RiverKeepers Fund	$30,000	12/10/26	Reimbursement only, requires upfront spending.
13	Clean Earth Foundation	$35,000	11/18/26	Only 501c3 fiscal sponsors can apply? Verify.
14	Neighborhood Green Grants	$12,000	rolling	Need project location. Link missing.
15	Eco Innovations Program	$50,000	12/31/26	Research institutions only. May need university partner.

All 15 records are fictional. Blank fields, inconsistent formatting, and ambiguous notes are intentional.
Problems intentionally included
Issue	Rows	What the AI should do
Duplicate entry	1, 4	Recognize the same grant despite different names and formatting.
Missing deadline	9	Mark the deadline unknown instead of inventing one.
Expired opportunity	6	Flag the expired deadline even if the application page remains visible.
Geographic ineligibility	8	Reject a California-only opportunity for a Florida applicant.
Unusually high funding	10	Check the minimum organizational budget requirement.
Special character	11	Correctly process the apostrophe in O'Connor.
Inconsistent amounts	2, 4, 7	Interpret "$10k-50k," "25k," and "$40k" correctly.
Incomplete information	5, 14	Request verification rather than assume eligibility.

Nonprofit-specific gotchas
These are problems that a simple AI grant finder could easily overlook.

Gotcha 1 — Matching requirements

Row 7 offers $40,000 but requires a 20% match. The AI must flag that IDEAS For Us may need to contribute additional eligible funding or resources. It must also verify whether the percentage applies to the grant amount or the total project budget.

Gotcha 2 — Reimbursement funding

Row 12 offers $30,000, but funds are reimbursed after eligible expenses are paid. The AI should warn Sarah that IDEAS For Us would need sufficient cash available before reimbursement.

Gotcha 3 — Fiscal sponsorship

Row 13 mentions fiscal sponsors. A regular 501(c)(3) nonprofit is not automatically eligible for a grant specifically restricted to fiscal sponsors. The AI must verify the exact applicant requirements.

Gotcha 4 — Invitation-only funding

Row 5 appears to offer $100,000, but applications may require an invitation. The AI should not treat the opportunity as openly available.
What Sarah expects the AI to accomplish
When Sarah uploads this spreadsheet, she expects the automatic grant finder to:
1. Identify duplicate grants and remove expired opportunities from the active list.
2. Filter out grants with confirmed eligibility conflicts.
3. Flag unclear requirements, missing deadlines, and financial obligations.
4. Rank promising grants based on IDEAS For Us's environmental mission and verified eligibility.
5. Explain why each opportunity was accepted, rejected, or marked for further research, including supporting source links.
Success criteria: The AI should produce a shorter, more useful list of grants without inventing information or overlooking important requirements.