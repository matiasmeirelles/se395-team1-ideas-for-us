# Persona: Program Manager
**Author:** Tristan Willing
**Saved:** 11/17/2026, 4:02:49 PM

## Persona

Persona: Marisol Reyes, Program Manager

Marisol Reyes, 34
Program Manager, Fleet Farming and Community Programs, IDEAS For Us (Orlando, FL)

Marisol has been with the organization for four years. She started as a volunteer coordinator. Now she runs Fleet Farming day to day: volunteer bike-farming rides, homeowner “farmlette” sign-ups, harvest logs and partner gardens. She also supports a few local hubs. She doesn’t write grants. Brianna in development does that, and she’s part-time. Marisol’s job is to supply the program facts and confirm that a grant actually fits what the program does. In a typical week she spends two mornings in the field, one afternoon in a partner meeting, and the rest answering messages. Her laptop is often covered in soil.

Tech comfort: moderate, mostly on her phone

What she uses every day:

Gmail and Google Calendar, usually with 40+ unread emails
Google Drive and Sheets: the harvest tracker, volunteer roster and a “Program Stats MASTER (use this one)” doc
WhatsApp groups for volunteers, and Slack for staff, which she checks less often
Instagram and Canva for program posts
Zoom for partner calls
Her phone, for almost everything when she’s in the field

What she’s tried or never used:

Grant databases like Instrumentl or Candid. Brianna has the login, and Marisol has never opened them.
Salesforce or any real CRM. The organization talked about it once.
Airtable. She opened it once, felt lost and closed the tab.
ChatGPT. She has used it a few times to fix the wording of an email. She has never trusted it with numbers.

She can learn new software, but she won’t sit through a tutorial. If she can’t do something useful in her first 10 minutes, she won’t come back.

Top frustration

She’s asked to vet grants she has no time to read, and then she retypes the same program numbers over and over.

Here’s how it usually goes. Brianna sends a link on a Tuesday night: “Does this fit Fleet Farming? Due Friday.” Marisol opens a 28-page RFP on her phone between garden visits. On page 19 she finds the problem. The grant needs a 1:1 cash match. Or it’s for Miami-Dade only. Or “environmental” turns out to mean brownfield cleanup, not urban agriculture. That’s 40 minutes gone on a no.

When a grant does fit, she gets a doc full of questions: pounds harvested, number of active farmlettes, volunteer hours, households served. She answers them from the “MASTER” sheet, which hasn’t been fully updated since spring. Last cycle, two applications went out with different volunteer-hour totals, and a funder asked about it. She still thinks about that.

Dealbreaker

The tool invents or “rounds up” anything about her program.

If it drafts an application that says Fleet Farming “served 2,000 families” when she never gave it that number, she’s done for good. She would rather see a blank labeled “[need number from Marisol]” than a confident guess. Funders talk to each other. Her name and the organization’s credibility are behind every number.

A close second: making her re-enter everything at setup. If day one means filling in 30 form fields about the program, she’ll put it off until next quarter, which really means never.

What she checks first to see if it “gets it”

She’ll type in “Fleet Farming.” Then she’ll look at whether the first grant it suggests shows the deal-breakers up front, without her having to open the RFP.

That means she can see these in the first few lines:

Whether Orlando or Orange County is eligible
Whether there’s a match requirement
Whether “environment” here includes urban agriculture and food access, or only conservation and remediation

## Synthetic Data

How messy it is

Same program, four names: “Fleet Farming,” “FF,” “Fleet Farm” and “fleet farming.”
Units and dates don’t match: “lbs,” “lb” and blank units; dates written as 1/14/25, 2025-02-10 and 3/2024; time periods given as “2024,” “CY2024,” “Q2,” “FY24-25 Q2,” “current” and “2025 YTD.”
Some values aren’t plain numbers: “~350,” “1.2k,” “N/A,” “$186,500 “ (with a space at the end), and “4,812 / 27,” a formula that broke when it was pasted.

Edge cases that would break a naive system

Duplicates that don’t match: two rows each for volunteer hours (1240 vs. 1240.5) and swarm rides (46 vs. 48), from different sources. Neither row is clearly the right one. “Q2” might also mean a calendar quarter instead of the fiscal one.
A suspiciously large number: 38,400 lbs harvested in 2024, against 4,812 in the harvest log, with Brianna’s note “use this one for the big asks?”
A required field left empty: “Households served” for 2024 has no value. The note just says to ask Jess.
Special characters: “Parramore – Café con Huertos 🌱” has an en dash, an accent and an emoji. Its notes also contain a comma and escaped double quotes.
A misleading number: “1.2k youth participants” comes from a school’s report. It’s probably the school’s total enrollment, not the number of students who took part.

The gotchas that take domain knowledge to catch

Hub numbers inflate the local total. The 38,400 lbs is very likely an organization-wide figure that includes hubs in other cities, like the Gainesville row (2,100 lbs, “hub reports to us”). Many environmental and food-access grants only count local impact, such as Orange County or Central Florida. If your tool puts 38,400 into a local application, it has overstated the program’s impact by about 8x on a document Marisol has to sign. That’s her dealbreaker.
“Counts toward match!!” may be wrong. The $41,056 in volunteer time is in-kind value. Grants that require a cash match won’t accept it. A tool that marks a match requirement as met because this row exists will give a false “fits.”
Households served may count the wrong people. The ~350 figure “includes farmlette hosts.” Those are homeowners lending their yards, not food-insecure residents receiving produce. USDA-style funders that define beneficiaries by income would reject that number.

A good tool would point out each of these and ask Marisol to confirm the number, without silently picking one.