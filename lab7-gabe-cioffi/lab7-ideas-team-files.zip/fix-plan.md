# Fix Plan
**Author:** Tristan Willing
**Saved:** 11/17/2026, 4:26:55 PM

| 3 | No spreadsheet import | Messy-data import | Add a CSV / Sheets import that keeps raw values and flags duplicates - Charlotte - Organize and import data I clean and legible format. 

| 1 | Topic search returns nothing ("sustainability" = 0) | First search | Search summaries, eligibility and focus areas; show a no-results hint - Gabe - add geographic filter for the correct grants and ensure accuracy. 

| 4 | "Sent" and "Approve for applications/" are misleading | Review controls | Rename to "Mark as submitted" and "Approve draft (does not submit)" - Leo - Rename labels for more accurate application updates.

| 5 | Geographically ineligible grants shown as appliable | First search (Keidanren) | Hide known exclusions by default - Tristan - filter Geographically ineligible grants out of the system and dont show these.