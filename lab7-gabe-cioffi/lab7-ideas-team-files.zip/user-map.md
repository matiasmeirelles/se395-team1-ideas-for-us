# User Map
**Author:** Charlotte Groton
**Saved:** 11/12/2026, 4:22:24 PM

1. Grant Writer	Finds grants, writes applications, and checks AI drafts.
2. Executive Director / CEO	Reviews all work.
3. Development Director	Manages strategy and prioritizes grant opportunities.
4. Grant Coordinator	Tracks grant deadlines, eligibility requirements, and application progress.
5. Program Manager	Provides project details and verifies that grants match environmental programs.
6. Finance Manager	Checks grant budgets, financial requirements, and funding restrictions.
7. Operations Manager	Makes sure the AI tool fits existing nonprofit workflows.
8. Environmental Project Coordinator	Identifies funding opportunities for specific sustainability projects.
9. Administrative Assistant	Organizes grant documentation, attachments, and deadlines.
10. Board Member	Reviews funding recommendations and evaluates organizational risks.